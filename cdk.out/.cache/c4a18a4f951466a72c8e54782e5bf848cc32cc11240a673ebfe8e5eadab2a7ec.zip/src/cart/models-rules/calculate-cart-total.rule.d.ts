import { CartItem } from '../../shared';
export declare function calculateCartTotal(items: CartItem[]): number;
