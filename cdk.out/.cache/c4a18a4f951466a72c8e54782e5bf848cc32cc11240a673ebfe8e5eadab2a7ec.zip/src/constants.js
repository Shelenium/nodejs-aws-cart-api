"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.JWT_CONFIG = void 0;
exports.JWT_CONFIG = {
    secret: 'secret',
    expiresIn: '12h',
};
//# sourceMappingURL=constants.js.map