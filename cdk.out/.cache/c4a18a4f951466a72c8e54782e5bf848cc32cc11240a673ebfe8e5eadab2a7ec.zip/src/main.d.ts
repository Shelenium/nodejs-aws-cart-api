import { INestApplication } from '@nestjs/common';
export declare function nestLambdaBootstrap(): Promise<INestApplication>;
